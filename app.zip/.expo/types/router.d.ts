/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/LoginScreen`; params?: Router.UnknownInputParams; } | { pathname: `/RegisterScreen`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/Home/HomeScreen`; params?: Router.UnknownInputParams; } | { pathname: `/Home/NewRecipeScreen`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/LoginScreen`; params?: Router.UnknownOutputParams; } | { pathname: `/RegisterScreen`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/Home/HomeScreen`; params?: Router.UnknownOutputParams; } | { pathname: `/Home/NewRecipeScreen`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/LoginScreen${`?${string}` | `#${string}` | ''}` | `/RegisterScreen${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/Home/HomeScreen${`?${string}` | `#${string}` | ''}` | `/Home/NewRecipeScreen${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/LoginScreen`; params?: Router.UnknownInputParams; } | { pathname: `/RegisterScreen`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/Home/HomeScreen`; params?: Router.UnknownInputParams; } | { pathname: `/Home/NewRecipeScreen`; params?: Router.UnknownInputParams; };
    }
  }
}
